# Clearbook design and execution plan

User authorization: build the recommended Perpl reconciliation project, publish it, and submit to Monad Metropolis autonomously. Primary user: a Perpl trader who needs to explain account balance changes and investigate incomplete exports. Success: exact accounting, original-record inspection, a working live read-only adapter, a public demo, open source, and completed submission with honest evidence.

## Scope and architecture
Browser React workspace; deterministic BigInt reconciliation library; browser-local Ed25519 request signatures; same-origin allowlisted GET proxy to Perpl (needed because upstream does not permit browser CORS); allowlisted read-only Monad RPC proxy. Private key lives only in browser memory. No database, trading, custody, automatic settlement, tax conclusions, invented traction, or AI-generated financial judgments.

Input: original Perpl AccountEvent records plus optional wallet snapshot and official context. Support a documented JSON export and raw atomic-unit CSV. Reconcile each instance/account separately. Preserve fee-inclusive `a`; split `f` into protocol and builder components without charging either twice. Separate cash flows, funding, execution outcomes, internal collateral movement, and unknown events. Display balance-sequence gaps, conflicting duplicate identities, missing pagination, and snapshot differences explicitly. Earliest observed opening balance is inferred (`b-a`), not proof that full history is present. Locked balance and unrealized position PnL are not added to spendable balance. Never label account balance reconciliation as total portfolio performance.

Synthetic demonstration fixtures are labelled and contain no fake transaction hashes. Live source panel independently checks configured chain ID, exchange bytecode and recent exchange transaction receipts. Receipt evidence proves transaction inclusion only, not all reported API amounts. Imported data stays in page memory; user can export it intentionally. Reports include methodological and provenance notes.

## Execution
1. Build ledger, import validation, sample clean/broken cases, and accounting tests.
2. Build interface and restricted API routes; implement request signing and cursor pagination with bounded limits and completeness flags.
3. Validate exact accounting, fee semantics, mixed accounts, large numbers, duplicate conflicts, missing records, stale snapshots, signing, and upstream restrictions.
4. Build and inspect desktop/mobile interface. Exercise live Monad and Perpl endpoints and preserve real evidence.
5. Publish public product and MIT-licensed GitHub source; document build dates, AI assistance, actual capabilities and limits.
6. Record concise product demo and founder/problem pitch with truthful attribution; prepare logo and submission materials.
7. Select Onchain Finance and eligible Perpl analytics bounty, submit, and preserve visible submission confirmation.

Self-review: no undefined external services, no invented real account history, no unbounded fetch targets, no fee double counting, no unsupported claims of full financial performance. If authenticated end-to-end verification cannot be performed without user-owned keys, report that limit and make the reproducible adapter tests and import workflow available.
