const hosts={mainnet:'https://app.perpl.xyz/api',testnet:'https://testnet.perpl.xyz/api'};
export async function GET(request:Request){
  const url=new URL(request.url),network=url.searchParams.get('network'),target=url.searchParams.get('target');
  if((network!=='mainnet'&&network!=='testnet')||!target)return Response.json({error:'Invalid network or target'},{status:400});
  const parsed=new URL('https://local.invalid'+target);
  if(!['/v1/pub/context','/v1/trading/account-history','/v1/trading/wallet'].includes(parsed.pathname)||target.length>4096||target.includes('#')||target.startsWith('//')||[...parsed.searchParams.keys()].some(k=>!['count','page'].includes(k)))return Response.json({error:'Read endpoint is not allowed'},{status:400});
  if(parsed.searchParams.has('count')&&(!/^\d+$/.test(parsed.searchParams.get('count')!)||Number(parsed.searchParams.get('count'))>100||Number(parsed.searchParams.get('count'))<1))return Response.json({error:'Invalid page size'},{status:400});
  const headers=new Headers({Accept:'application/json'});
  if(parsed.pathname!=='/v1/pub/context')for(const name of ['X-API-Key','X-API-Timestamp','X-API-Nonce','X-API-Signature']){const value=request.headers.get(name);if(!value||value.length>2048)return Response.json({error:'Missing signed request headers'},{status:401});headers.set(name,value);}
  try{const upstream=await fetch(hosts[network]+target,{method:'GET',headers,redirect:'manual',signal:AbortSignal.timeout(15000)});if(upstream.status>=300&&upstream.status<400)return Response.json({error:'Unexpected upstream redirect'},{status:502});const text=await upstream.text();if(text.length>3000000)return Response.json({error:'Upstream response too large'},{status:502});return new Response(text,{status:upstream.status,headers:{'Content-Type':upstream.headers.get('content-type')??'application/json','Cache-Control':'no-store','X-Content-Type-Options':'nosniff'}});}catch{return Response.json({error:'Perpl service unavailable'},{status:502});}
}
