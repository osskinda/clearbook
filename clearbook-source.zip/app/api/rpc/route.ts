const networks={mainnet:{rpc:'https://rpc.monad.xyz',exchange:'0x34b6552d57a35a1d042ccae1951bd1c370112a6f'},testnet:{rpc:'https://testnet-rpc.monad.xyz',exchange:'0x1964c32f0be608e7d29302aff5e61268e72080cc'}};
export async function POST(request:Request){
  try{
    if(Number(request.headers.get('content-length'))>8192)return Response.json({error:'Request too large'},{status:413});
    const text=await request.text();if(text.length>8192)return Response.json({error:'Request too large'},{status:413});const body=JSON.parse(text),network=body.network;
    if(network!=='mainnet'&&network!=='testnet')return Response.json({error:'Unknown network'},{status:400});
    const config=networks[network as keyof typeof networks],method=body.method,params=body.params??[];
    if(!Array.isArray(params)||!['eth_chainId','eth_blockNumber','eth_getCode','eth_getLogs','eth_getTransactionReceipt'].includes(method))return Response.json({error:'RPC method is not allowed'},{status:400});
    if(['eth_chainId','eth_blockNumber'].includes(method)&&params.length!==0)throw new Error();
    if(method==='eth_getCode'&&(params.length!==2||String(params[0]).toLowerCase()!==config.exchange||params[1]!=='latest'))throw new Error();
    if(method==='eth_getTransactionReceipt'&&(params.length!==1||!/^0x[0-9a-fA-F]{64}$/.test(params[0])))throw new Error();
    if(method==='eth_getLogs'){const q=params[0];if(params.length!==1||!q||String(q.address).toLowerCase()!==config.exchange||Object.keys(q).some(k=>!['address','fromBlock','toBlock'].includes(k))||!/^0x[0-9a-fA-F]+$/.test(q.fromBlock)||!/^0x[0-9a-fA-F]+$/.test(q.toBlock)||BigInt(q.toBlock)<BigInt(q.fromBlock)||BigInt(q.toBlock)-BigInt(q.fromBlock)>99n)throw new Error();}
    const res=await fetch(config.rpc,{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({jsonrpc:'2.0',id:1,method,params}),signal:AbortSignal.timeout(15000)});
    const answer=await res.text();if(answer.length>3000000)return Response.json({error:'Response too large'},{status:502});return new Response(answer,{status:res.status,headers:{'Content-Type':'application/json','Cache-Control':'no-store'}});
  }catch{return Response.json({error:'Invalid request or unavailable Monad RPC'},{status:400});}
}
