export type Network = 'mainnet' | 'testnet';
export type EventRecord = { at: { b?: number; t?: number; tx?: number; txid?: string; l?: number }; in: number; id: number; et: number; a: string; b: string; lb?: string; f: string; bfa?: string; m?: number; o?: number; p?: number; r?: number };
export type Dataset = { version: 1; name: string; network: Network; source: 'demo'|'import'|'live'; complete: boolean; decimals: number; symbol: string; events: EventRecord[]; snapshot?: { sn: number; as: { in: number; id: number; b: string }[] }; context?: unknown; importedAt?: string };
export type Finding = { level: 'error'|'warning'|'info'; title: string; detail: string; row?: string };
export type LedgerRow = { key: string; event: EventRecord; type: string; category: string; amount: bigint; balance: bigint; gross: bigint; fee: bigint; builderFee: bigint; protocolFee: bigint; expected: bigint; gap: bigint };
export const EVENT_TYPES: Record<number,string> = { 0:'Unspecified',1:'Deposit',2:'Withdrawal',3:'Collateral increase',4:'Settlement',5:'Liquidation',6:'Transfer to protocol',7:'Transfer from protocol',8:'Funding',9:'Deleveraging',10:'Unwinding',11:'Collateral decrease',12:'Forwarding reset' };
const group = (n: number) => [1,2].includes(n)?'Cash flow':[4,5,9,10].includes(n)?'Execution':n===8?'Funding':[3,11].includes(n)?'Collateral':[6,7].includes(n)?'Protocol transfer':n===12?'Administrative':'Unclassified';
const integer = (x: unknown, label: string): string => { if(typeof x!=='string'||! /^-?\d+$/.test(x)||x.length>90) throw new Error(`${label} must be an integer string in raw collateral units.`); return BigInt(x).toString(); };
const safe = (x: unknown, label: string, optional=false) => { if(optional && x===undefined)return; if(!Number.isSafeInteger(x)||Number(x)<0)throw new Error(`${label} must be a nonnegative safe integer.`); };
export function validateDataset(input: unknown, source: Dataset['source']='import'): Dataset {
  if(!input||typeof input!=='object')throw new Error('Import a Clearbook JSON object or a raw Perpl event array.');
  const obj = input as Record<string,unknown>;
  if(obj.data&&typeof obj.data==='object'&&!obj.events)return validateDataset(obj.data,source);
  if(!Array.isArray(obj.events)||obj.events.length>10000)throw new Error('Expected events array, up to 10,000 records.');
  if(obj.network!=='mainnet'&&obj.network!=='testnet')throw new Error('network must be mainnet or testnet.');
  if(!Number.isInteger(obj.decimals)||Number(obj.decimals)<0||Number(obj.decimals)>36)throw new Error('decimals must be between 0 and 36.');
  const events=obj.events.map((value,i)=>{
    if(!value||typeof value!=='object')throw new Error(`Record ${i+1} is not an object.`);
    const e=value as EventRecord;
    safe(e.in,`Record ${i+1} instance`);safe(e.id,`Record ${i+1} account`);safe(e.et,`Record ${i+1} type`);
    if(!e.at||typeof e.at!=='object')throw new Error(`Record ${i+1} needs at timestamp coordinates.`);
    for(const [k,v]of Object.entries(e.at)) if(['b','t','tx','l'].includes(k))safe(v,`Record ${i+1} at.${k}`,true);
    if(e.at.b===undefined&&e.at.t===undefined)throw new Error(`Record ${i+1} needs a block or timestamp.`);
    if(e.at.txid!==undefined&&!/^0x[0-9a-fA-F]{64}$/.test(e.at.txid))throw new Error(`Record ${i+1} transaction hash is invalid.`);
    for(const k of ['m','o','p','r']as const)safe(e[k],`Record ${i+1} ${k}`,true);
    const event:EventRecord={at:{...e.at},in:e.in,id:e.id,et:e.et,a:integer(e.a,`Record ${i+1} amount`),b:integer(e.b,`Record ${i+1} balance`),f:integer(e.f??'0',`Record ${i+1} fee`)};
    for(const k of ['lb','bfa']as const)if(e[k]!==undefined)event[k]=integer(e[k],`Record ${i+1} ${k}`);
    for(const k of ['m','o','p','r']as const)if(e[k]!==undefined)event[k]=e[k];
    return event;
  });
  const result:Dataset={version:1,name:typeof obj.name==='string'?obj.name.slice(0,120):'Imported account history',network:obj.network,source:source==='import'&&obj.source==='demo'?'demo':source,complete:obj.complete===true,decimals:Number(obj.decimals),symbol:typeof obj.symbol==='string'?obj.symbol.slice(0,12):'collateral',events,importedAt:new Date().toISOString()};
  if(obj.snapshot){const s=obj.snapshot as Dataset['snapshot'];if(!s||!Array.isArray(s.as))throw new Error('snapshot.as must be an array.');safe(s.sn,'Snapshot block');result.snapshot={sn:s.sn,as:s.as.map(a=>{safe(a.in,'Snapshot instance');safe(a.id,'Snapshot account');return{in:a.in,id:a.id,b:integer(a.b,'Snapshot balance')};})};}
  if(obj.context)result.context=obj.context;
  return result;
}
export function eventKey(e:EventRecord,index=0):string {
  if(e.at.b!==undefined&&e.at.tx!==undefined&&e.at.l!==undefined)return `${e.in}:${e.id}:${e.at.b}:${e.at.tx}:${e.at.l}`;
  if(e.at.txid&&e.at.l!==undefined)return `${e.in}:${e.id}:${e.at.txid.toLowerCase()}:${e.at.l}`;
  return `unlocated:${index}`;
}
export function reconcile(data:Dataset,accountKey?:string) {
  const accounts=[...new Set(data.events.map(e=>`${e.in}:${e.id}`))];
  const selected=accountKey??accounts[0];
  const issues:Finding[]=[];
  const seen=new Map<string,EventRecord>();
  let duplicates=0;
  const canonical=(e:EventRecord)=>JSON.stringify([e.at.b,e.at.t,e.at.tx,e.at.txid?.toLowerCase(),e.at.l,e.in,e.id,e.et,e.a,e.b,e.lb,e.f,e.bfa,e.m,e.o,e.p,e.r]);
  const events=data.events.filter(e=>`${e.in}:${e.id}`===selected).filter((e,i)=>{const key=eventKey(e,i);const old=seen.get(key);if(!old){seen.set(key,e);return true;}if(canonical(old)===canonical(e)){duplicates++;return false;}issues.push({level:'error',title:'Conflicting duplicate',detail:`Two different records use the same event identity ${key}. The first is retained; this report is not reconciled.`,row:key});return false;});
  const compare=(a:EventRecord,b:EventRecord)=>{
    if(a.at.b!==undefined&&b.at.b!==undefined)return a.at.b-b.at.b||(a.at.tx??0)-(b.at.tx??0)||(a.at.l??0)-(b.at.l??0)||(a.at.t??0)-(b.at.t??0);
    return (a.at.t??0)-(b.at.t??0)||(a.at.b??0)-(b.at.b??0);
  };
  events.sort(compare);
  if(events.some(e=>eventKey(e).startsWith('unlocated:')))issues.push({level:'warning',title:'Incomplete event coordinates',detail:'Some records lack a transaction/log identity. Deduplication and within-block ordering cannot be fully verified.'});
  if(!data.complete)issues.push({level:'warning',title:'Partial history',detail:'Pagination or export completeness is unconfirmed. Matching balances only checks the supplied window.'});
  if(duplicates)issues.push({level:'info',title:'Repeated records removed',detail:`${duplicates} identical overlap record${duplicates===1?'':'s'} counted once.`});
  const opening=events.length?BigInt(events[0].b)-BigInt(events[0].a):0n;
  let previous=opening;
  const rows:LedgerRow[]=events.map((e,i)=>{
    const amount=BigInt(e.a),balance=BigInt(e.b),fee=BigInt(e.f),builderFee=BigInt(e.bfa??'0'),expected=previous+amount,gap=balance-expected,key=eventKey(e,i);
    if(gap!==0n)issues.push({level:'error',title:'Balance sequence gap',detail:`Record ${i+1}: reported balance differs from previous balance plus the fee-inclusive change. Missing records, mixed exports or inconsistent values may be responsible.`,row:key});
    if(builderFee!==0n&&(fee<0n||builderFee<0n||builderFee>fee))issues.push({level:'warning',title:'Unexpected builder fee',detail:`Record ${i+1} has a builder fee outside the gross fee. Inspect the source.`,row:key});
    if(group(e.et)==='Unclassified')issues.push({level:'warning',title:'Unclassified event',detail:`Event type ${e.et} is retained in the balance calculation but excluded from trading-result claims.`,row:key});
    previous=balance;
    return{key,event:e,type:EVENT_TYPES[e.et]??`Unknown (${e.et})`,category:group(e.et),amount,balance,gross:amount+fee,fee,builderFee,protocolFee:fee-builderFee,expected,gap};
  });
  const total=(pick:(row:LedgerRow)=>bigint)=>rows.reduce((sum,row)=>sum+pick(row),0n);
  const fees=total(r=>r.fee),builderFees=total(r=>r.builderFee),cash=total(r=>r.category==='Cash flow'?r.gross:0n),execution=total(r=>r.category==='Execution'?r.gross:0n),funding=total(r=>r.category==='Funding'?r.gross:0n),collateral=total(r=>r.category==='Collateral'?r.gross:0n),transfers=total(r=>r.category==='Protocol transfer'?r.gross:0n),other=total(r=>['Unclassified','Administrative'].includes(r.category)?r.gross:0n),net=total(r=>r.amount),closing=rows.at(-1)?.balance??opening,explained=opening+net,discrepancy=closing-explained;
  const snapshot=data.snapshot?.as.find(a=>`${a.in}:${a.id}`===selected);
  if(data.snapshot&&!snapshot&&rows.length)issues.push({level:'warning',title:'Account missing from snapshot',detail:'The supplied wallet snapshot does not contain the selected account.'});
  let snapshotGap:bigint|undefined;
  if(snapshot&&rows.length){const lastBlock=rows.at(-1)!.event.at.b;if(lastBlock===undefined||data.snapshot!.sn<lastBlock)issues.push({level:'warning',title:'Snapshot cannot anchor this window',detail:'Snapshot is older than the latest event, or latest event block is unknown.'});else{snapshotGap=BigInt(snapshot.b)-closing;if(snapshotGap!==0n)issues.push({level:'error',title:'Snapshot differs from latest record',detail:'The wallet snapshot differs from the latest event balance. History may be incomplete or the snapshot may include later activity.'});}}
  const status=issues.some(x=>x.level==='error')?'Mismatch':issues.some(x=>x.level==='warning')?'Review needed':rows.length?'Window reconciled':'No records';
  return{accounts,selected,rows,issues,duplicates,opening,closing,explained,discrepancy,net,fees,builderFees,protocolFees:fees-builderFees,cash,execution,funding,collateral,transfers,other,snapshotGap,status};
}
export function units(value:bigint,decimals:number,precision=2):string {
  const sign=value<0n?'-':'';const n=value<0n?-value:value;const scale=10n**BigInt(decimals),whole=n/scale,fraction=(n%scale).toString().padStart(decimals,'0');
  return sign+whole.toString().replace(/\B(?=(\d{3})+(?!\d))/g,',')+(decimals&&precision?'.'+fraction.slice(0,Math.min(decimals,precision)): '');
}
export function exactUnits(value:bigint,decimals:number){return units(value,decimals,decimals);}
export function parseCsv(text:string,network:Network,decimals:number,symbol:string):Dataset {
  const lines=text.replace(/^\uFEFF/,'').trim().split(/\r?\n/);if(lines.length<2)throw new Error('CSV needs headers and at least one record.');
  const split=(line:string)=>{const out:string[]=[];let field='',quoted=false;for(let i=0;i<line.length;i++){const c=line[i];if(c==='"'){if(quoted&&line[i+1]==='"'){field+='"';i++;}else quoted=!quoted;}else if(c===','&&!quoted){out.push(field);field='';}else field+=c;}if(quoted)throw new Error('Malformed CSV quoting.');out.push(field);return out;};
  const headers=split(lines[0]).map(h=>h.trim());const required=['account_id','instance_id','event_type','amount','balance','fee'];if(required.some(k=>!headers.includes(k)))throw new Error('CSV requires '+required.join(', ')+'. Amounts must be atomic-unit integers.');
  const events=lines.slice(1).filter(l=>l.trim()).map(line=>{const cells=split(line);if(cells.length!==headers.length)throw new Error('CSV row width differs from headers. Multiline cells are unsupported.');const r=Object.fromEntries(headers.map((h,i)=>[h,cells[i].trim()]));const num=(k:string)=>r[k]?Number(r[k]):undefined;return{in:num('instance_id'),id:num('account_id'),et:num('event_type'),a:r.amount,b:r.balance,f:r.fee,bfa:r.builder_fee||undefined,lb:r.locked_balance||undefined,m:num('market_id'),at:{b:num('block'),t:num('timestamp'),tx:num('tx_index'),l:num('log_index'),txid:r.tx_hash||undefined}};});
  return validateDataset({network,decimals,symbol,name:'CSV import',complete:false,events});
}
