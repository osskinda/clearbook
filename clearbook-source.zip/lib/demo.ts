import type {Dataset,EventRecord} from './ledger';
const base=Date.UTC(2026,9,9,8);
const raw=(b:number)=>String(b*1e6);
let balance=0;
const specifications=[{et:1,a:1000,f:0},{et:4,a:120,f:3,bfa:.5},{et:8,a:-8,f:0},{et:4,a:-42,f:2,bfa:.3},{et:1,a:250,f:0},{et:4,a:65,f:1.5,bfa:.2},{et:8,a:3,f:0},{et:2,a:-300,f:0},{et:4,a:-20,f:1,bfa:.1},{et:8,a:-4,f:0}];
export const DEMO:Dataset={version:1,name:'Example account · 42',network:'mainnet',source:'demo',complete:true,decimals:6,symbol:'AUSD',events:specifications.map((s,i)=>{balance+=s.a;return{in:1,id:42,et:s.et,a:raw(s.a),b:raw(balance),f:raw(s.f),bfa:raw(s.bfa??0),lb:'0',m:[1,2].includes(s.et)?undefined:1,at:{b:1000+i,t:base+i*3600000,tx:0,l:0}}as EventRecord;}),snapshot:{sn:1010,as:[{in:1,id:42,b:raw(balance)}]}};
export function demo(broken=false):Dataset {const data=structuredClone(DEMO);if(broken){data.name='Example · missing funding record';data.events.splice(2,1);}return data;}
