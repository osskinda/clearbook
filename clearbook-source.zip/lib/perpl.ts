import * as ed from '@noble/ed25519';
import {validateDataset,type Dataset,type Network} from './ledger.ts';
export const NETWORKS={mainnet:{chainId:143,exchange:'0x34B6552d57a35a1D042CcAe1951BD1C370112a6F',explorer:'https://monadscan.com'},testnet:{chainId:10143,exchange:'0x1964c32f0be608e7d29302aff5e61268e72080cc',explorer:'https://testnet.monadscan.com'}};
const hex=(bytes:Uint8Array)=>Array.from(bytes,x=>x.toString(16).padStart(2,'0')).join('');
const base64url=(bytes:Uint8Array)=>btoa(String.fromCharCode(...bytes)).replace(/\+/g,'-').replace(/\//g,'_').replace(/=+$/,'');
export async function signedHeaders(network:Network,target:string,token:string,secret:Uint8Array){
  const timestamp=String(Date.now()),nonce=base64url(crypto.getRandomValues(new Uint8Array(16))),bodyHash=hex(new Uint8Array(await crypto.subtle.digest('SHA-256',new Uint8Array())));
  const canonical=[NETWORKS[network].chainId,'GET',target,timestamp,nonce,bodyHash].join('\n');
  const signature=await ed.signAsync(new TextEncoder().encode(canonical),secret);
  return{'X-API-Key':token,'X-API-Timestamp':timestamp,'X-API-Nonce':nonce,'X-API-Signature':base64url(signature)};
}
export async function loadPerpl(network:Network,token:string,secretHex:string,onProgress:(message:string)=>void,signal?:AbortSignal):Promise<Dataset>{
  const h=secretHex.trim().replace(/^0x/,'');if(!/^[a-fA-F0-9]{64}$/.test(h))throw new Error('Use the 32-byte Ed25519 API secret from Perpl, not a wallet seed phrase.');if(!token.trim()||token.length>2048)throw new Error('Enter your Perpl API token.');
  const secret=Uint8Array.from(h.match(/../g)!,x=>parseInt(x,16));
  try{
    const request=async<T>(target:string,authenticated=true):Promise<T>=>{const headers=authenticated?await signedHeaders(network,target,token.trim(),secret):{};const res=await fetch(`/api/perpl?network=${network}&target=${encodeURIComponent(target)}`,{headers,signal,cache:'no-store'});if(!res.ok){const message=res.status===401?'Perpl rejected the signature. Check the key, network, expiry and computer clock.':res.status===429?'Perpl rate limit reached. Wait before trying again.':`Perpl request failed (${res.status}).`;throw new Error(message);}return await res.json() as T;};
    const context=await request<{chain:{chain_id:number};instances:{id:number;collateral_token_id:number}[];tokens:{id:number;decimals:number;symbol:string}[]}>('/v1/pub/context',false);if(context.chain?.chain_id!==NETWORKS[network].chainId)throw new Error('Perpl context reports an unexpected chain. Import stopped.');
    const events:unknown[]=[];let cursor='',complete=false;const cursors=new Set<string>();
    for(let i=0;i<100;i++){
      onProgress(`Reading history · ${events.length} records`);
      const page=await request<{d:unknown[];np:string}>('/v1/trading/account-history?count=100'+(cursor?'&page='+encodeURIComponent(cursor):''));
      if(!Array.isArray(page.d))throw new Error('Perpl returned an unexpected history shape.');events.push(...page.d);
      if(!page.np){complete=true;break;}if(typeof page.np!=='string'||cursors.has(page.np))throw new Error('Repeated pagination cursor. History is not complete.');cursors.add(page.np);cursor=page.np;
    }
    onProgress('Reading latest wallet snapshot');const wallet=await request<{sn:number;as:{in:number;id:number;b:string}[]}>('/v1/trading/wallet');
    if(!Array.isArray(wallet.as))throw new Error('Perpl returned an unexpected wallet snapshot.');
    const usedInstances=new Set((events as {in:number}[]).map(e=>e.in));const instances=context.instances.filter((i:{id:number})=>usedInstances.has(i.id));
    const tokenIds=new Set(instances.map((i:{collateral_token_id:number})=>i.collateral_token_id));if(tokenIds.size>1)throw new Error('Accounts use different collateral tokens. Export and import one collateral group at a time.');
    const collateral=context.tokens.find((t:{id:number})=>t.id===[...tokenIds][0])??context.tokens.find((t:{id:number})=>t.id===context.instances[0]?.collateral_token_id);if(!collateral)throw new Error('Collateral token metadata is missing.');
    return validateDataset({version:1,name:'Perpl live account history',network,source:'live',complete,decimals:collateral.decimals,symbol:collateral.symbol,events,snapshot:{sn:wallet.sn,as:wallet.as},context},'live');
  }finally{secret.fill(0);}
}
